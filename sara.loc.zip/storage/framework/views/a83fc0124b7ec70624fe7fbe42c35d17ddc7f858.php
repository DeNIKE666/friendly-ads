

<?php $__env->startSection('title' , 'Управление пользователями'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold">Пользователи</h2>
                    <h5 class="text-white op-7 mb-2">Все пользователи сервиса</h5>
                </div>
                <div class="ml-md-auto py-2 py-md-0">
                    <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-white btn-border btn-round mr-2">Создать нового пользователя</a>
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        <div class="card">
            <?php if($users->isEmpty()): ?>
                <div class="card">
                    <div class="alert alert-danger mb-0" role="alert">
                        В системе пока нет категорий
                    </div>
                </div>
            <?php else: ?>
            <table>
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Имя</th>
                    <th scope="col">Логин</th>
                    <th scope="col">Почта</th>
                    <th scope="col">Телеграм</th>
                    <th scope="col">Сайтов</th>
                    <th scope="col">Рейтинг</th>
                    <th scope="col">Баланс</th>
                    <th scope="col">Бан</th>
                    <th scope="col"></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td data-label="#"><?php echo e($user->id); ?></td>
                        <td data-label="Имя"><?php echo e($user->name); ?></td>
                        <td data-label="Логин"><?php echo e($user->username); ?></td>
                        <td data-label="Почта"><?php echo e($user->email); ?></td>
                        <td data-label="Телеграм"><?php echo e($user->telegram_id ?: 'Не указан'); ?></td>
                        <td data-label="Сайтов"><?php echo e($user->sites->count()); ?></td>
                        <td data-label="Рейтинг"><?php echo e($user->sites->sum('rating')); ?></td>
                        <td data-label="Баланс"><?php echo e($user->balance); ?></td>
                        <td data-label="Рейтинг"><?php echo e($user->isBanned ? 'забанен' : 'не забанен'); ?></td>
                        <td>
                            <div class="d-flex justify-content-end">
                                <a href="<?php echo e(route('users.sites', $user)); ?>" class="btn btn-sm btn-outline-secondary mr-1"><span class="fal fa-sitemap"></span></a>
                                <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-sm btn-outline-primary mr-1"><span class="fal fa-edit"></span></a>

                                <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><span class="fal fa-trash"></span></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
           <?php endif; ?>
        </div>

        <div class="d-flex justify-content-center">
            <?php echo e($users->links()); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/admin/users/index.blade.php ENDPATH**/ ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> <?php echo e('| ' . env('APP_NAME')); ?></title>

    <meta name="description" content="<?php echo $__env->yieldContent('description' , config('ads_friendly.meta.description')); ?>">

    <!-- All Css -->
    <link href="<?php echo e(mix('/assets/frontend/css/main.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="green-skin bg-light">
<!-- ============================================================== -->
<!-- Preloader - style you can find in spinners.css -->
<!-- ============================================================== -->
<div class="Loader"></div>

<!-- ============================================================== -->
<!-- Main wrapper - style you can find in pages.scss -->
<!-- ============================================================== -->
<div id="main-wrapper">

    <?php echo $__env->make('__shared.frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(request()->routeIs('frontend')): ?>
        <!-- ============================ Hero Banner  Start================================== -->
            <div class="hero-header jumbo-banner text-center"
                 style="background: url(<?php echo e(asset('images/frontend/bg_header.png')); ?>);" data-overlay="6">
                <div class="container">
                    <h2><?php echo e(env('APP_NAME')); ?> - сервис по продвижению ссылок</h2>
                    <p class="lead">продвигайте ваши ссылки на популярных интернет площадках или соц сетях, за счет исполнителей</p>
                    <div class="search-big-form no-border search-shadow">
                        <div class="row m-0">
                            <div class="col-lg-10 col-md-10 col-sm-10 p-0">
                                <div class="form-group">
                                    <select id="category" class="js-states form-control" name="category">
                                        <option value="" selected>&nbsp;</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <i class="ti-layers"></i>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-12 p-0">
                                <button type="submit" class="btn btn-primary full-width selection_of_tasks"><i class="fal fa-paper-plane"></i> подобрать</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    <?php endif; ?>

    <!-- ============================ Hero Banner End ================================== -->

    <div id="app">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php echo $__env->make('__shared.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>

<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->

<script src="<?php echo e(mix('/assets/frontend/js/vendor.js')); ?>"></script>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>

<script>
    $('.selection_of_tasks').click(function () {
        let category = $('#category').val();

        if (category) {
            window.location.href = '/projects/?category_id=' + category
        }
    })
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>

<!-- ============================================================== -->
<!-- This page plugins -->
<!-- ============================================================== -->

</body>
</html><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/layouts/frontend.blade.php ENDPATH**/ ?>
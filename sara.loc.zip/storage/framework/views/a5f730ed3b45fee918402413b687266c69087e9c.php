<!-- Sidebar -->
<div class="sidebar sidebar-style-2">
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">
            <ul class="nav nav-primary">
                <li class="nav-section">
                    <h4 class="text-section">Навигация</h4>
                </li>

                <li class="nav-item">
                    <a href="">
                        <i class="fal fa-layer-plus"></i>
                        <p>РАЗДЕЛ 1</p>
                    </a>
                </li>

            </ul>
        </div>
    </div>
</div>
<!-- End Sidebar -->
<?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/__shared/cabinets/menu_sidebar.blade.php ENDPATH**/ ?>
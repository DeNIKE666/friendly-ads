

<?php $__env->startSection('title' , 'История пополнений'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold">История</h2>
                    <h5 class="text-white op-7 mb-2">Ваша история пополнений средств</h5>
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        <div class="card card-body full-height">
            <table>
                <thead>
                <tr>
                    <th scope="col">Наименование</th>
                    <th scope="col">Сумма</th>
                    <th scope="col">Платёжная система</th>
                    <th scope="col">Тип оплаты</th>
                    <th scope="col">Статус</th>
                </tr>
                </thead>
                <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td data-label="Наименование"><?php echo e($history->title); ?></td>
                        <td data-label="Сумма"><?php echo e($history->amount); ?> руб.</td>
                        <td data-label="Платёжная система"><?php echo e($history->pay_system); ?></td>
                        <td data-label="Тип оплаты">
                            <?php switch($history->action_pay):
                                case ('add-balance'): ?>
                                  пополнение
                                <?php break; ?>
                                <?php case ('pay-order'): ?>
                                  оплата заказа
                                <?php break; ?>
                            <?php endswitch; ?>
                        </td>
                        <td data-label="Статус">
                            <?php if($history->status == 0): ?>
                                <a href="">перейти к оплате</a>
                            <?php elseif($history->status == 1): ?>
                                <span class="badge badge-success">оплачен</span>
                            <?php elseif($history->status == 2): ?>
                                <span class="badge badge-danger">не оплачен</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center p-5">
                            На данный момент история пуста
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cabinet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/cabinets/customer/finance/history.blade.php ENDPATH**/ ?>
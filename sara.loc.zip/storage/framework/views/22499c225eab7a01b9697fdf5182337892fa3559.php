

<?php $__env->startSection('title' , 'Личный кабинет исполнителя'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        //
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cabinets.executor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/cabinets/executor/index.blade.php ENDPATH**/ ?>
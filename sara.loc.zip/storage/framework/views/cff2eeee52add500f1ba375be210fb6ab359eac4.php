

<?php $__env->startSection('title' , 'Просмотр предложения'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold">Просмотр</h2>
                    <h5 class="text-white op-7 mb-2">Просмотр предложения </h5>
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        <div class="d-flex justify-content-center">
            <div id="subscribe-task" data-id="<?php echo e($task->id); ?>" class="col-md-6">
                <div class="card card-post card-round">
                    <div class="card-body">
                        <div class="d-flex">
                            <div class="avatar">
                                <img src="<?php echo e(asset('images/noavatar.png')); ?>" alt="..." class="avatar-img rounded-circle">
                            </div>
                            <div class="info-post ml-2">
                                <p class="username"><?php echo e($task->user->username); ?></p>
                                <div style="width: 285px">
                                    <?php echo e($task->title); ?>

                                </div>
                            </div>
                        </div>
                        <div class="separator-solid"></div>
                        <p class="card-category text-info mb-1"><a href="#"><?php echo e($task->category->name); ?></a></p>
                        <p class="card-text text-black-50"><?php echo e($task->description); ?></p>
                        <p class="card-text">Бюджет: <b><?php echo e($task->amount); ?></b> руб. </p>
                        <p class="card-text">Срок: <b><?php echo e($task->period); ?></b> дней. </p>

                        <p class="card-text">
                            Тип контента:
                            <b><?php echo e(config('ads_friendly.type_task.' . $task->type_task )); ?> </b>
                        </p>

                        <p class="card-text">
                            Позиция размещения:
                            <b><?php echo e(config('ads_friendly.type_position.' . $task->type_position )); ?> </b>
                        </p>

                        <p class="card-text text-secondary">
                            Требуется сайтов:
                            <b><?php echo e($task->site_count); ?> / <?php echo e($task->subscribe->count()); ?>  </b>
                        </p>

                        <?php if(!$isSubscribe): ?>
                            <div class="alert alert-info" role="alert">
                                У вас еще нет отклика на данное задание, но вы можете <b>оставить отклик</b>
                            </div>
                        <?php else: ?>
                        <ol class="activity-feed" >
                            <?php $__currentLoopData = $task->subscribe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $executor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="feed-item feed-item-success">
                                    <span class="d-block text-muted text-uppercase font-weight-bold mb-2">
                                        <a href="<?php echo e(route('cabinet.show.profile', $executor->user)); ?>"><?php echo e($executor->user->username); ?></a>
                                    </span>
                                    <span class="text-muted text-black-50">сделал отклик</span> <br>
                                    <span class="text-muted text-black-50">получит <b>550 руб</b></span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php endif; ?>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cabinet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/cabinets/executor/offers/show.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title' , 'Редактировать задание'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold">Редактирование</h2>
                    <h5 class="text-white op-7 mb-2">Редактирование активного задания</h5>
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        <div class="d-flex justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">

                        <form action="<?php echo e(route('customer.tasks.update' , $task)); ?>" method="POST">
                            <div class="row">

                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="title">Название:</label>
                                        <input name="title" id="title" type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Название вашей задачи" value="<?php echo e(old('title', $task->title)); ?>">
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="period">Период:</label>
                                        <select class="form-control <?php $__errorArgs = ['period'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="period" name="period">
                                            <option value="" selected>-- Выберите период размещения</option>
                                            <option value="1"  <?php echo e(old('period') == '1' ? 'selected' : ''); ?>  <?php echo e($task->period == '1' ? 'selected' : ''); ?>>1 день</option>
                                            <option value="2"  <?php echo e(old('period') == '2' ? 'selected' : ''); ?>  <?php echo e($task->period == '2' ? 'selected' : ''); ?>>2 дня</option>
                                            <option value="3"  <?php echo e(old('period') == '3' ? 'selected' : ''); ?>  <?php echo e($task->period == '3' ? 'selected' : ''); ?>>3 дня</option>
                                            <option value="7"  <?php echo e(old('period') == '7' ? 'selected' : ''); ?>  <?php echo e($task->period == '7' ? 'selected' : ''); ?>>Неделя</option>
                                            <option value="14" <?php echo e(old('period') == '14' ? 'selected' : ''); ?>  <?php echo e($task->period == '14' ? 'selected' : ''); ?>>2 недели</option>
                                            <option value="30" <?php echo e(old('period') == '30' ? 'selected' : ''); ?>  <?php echo e($task->period == '30' ? 'selected' : ''); ?>>Месяц</option>
                                        </select>
                                        <?php $__errorArgs = ['period'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="amount">Бюджет:</label>
                                        <input name="amount" id="amount" type="text" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="10000" value="<?php echo e(old('amount', $task->amount)); ?>">
                                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="site_count">Сколько сайтов необходимо:</label>
                                        <input name="site_count" id="site_count" type="text" class="form-control <?php $__errorArgs = ['site_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="10" value="<?php echo e(old('site_count', $task->site_count)); ?>">
                                        <?php $__errorArgs = ['site_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>


                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Описание задачи:</label>
                                        <textarea name="description" id="editor" type="text" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Введите описание"><?php echo e(old('description', $task->description)); ?></textarea>
                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <p class="mt-3 mb-0">Слов введено: <span id="character-count"></span></p>
                                    </div>
                                </div>


                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="type_task">Тип задачи:</label>
                                        <select class="form-control <?php $__errorArgs = ['type_task'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="type_task" name="type_task">
                                            <option value="" selected>-- Выберите тип продвигаемого контента</option>
                                            <option value="link_product" <?php echo e(old('type_task') == 'link_product' ? 'selected' : ''); ?> <?php echo e($task->type_task == 'link_product' ? 'selected' : ''); ?>>Ссылка на продукт</option>
                                            <option value="link_video"   <?php echo e(old('type_task') == 'link_video'   ? 'selected' : ''); ?> <?php echo e($task->type_task == 'link_video' ? 'selected' : ''); ?>>Ссылка на видео</option>
                                            <option value="page"         <?php echo e(old('type_task') == 'page'         ? 'selected' : ''); ?> <?php echo e($task->type_task == 'page' ? 'selected' : ''); ?>>Страница сайта</option>
                                            <option value="app"          <?php echo e(old('type_task') == 'app'          ? 'selected' : ''); ?> <?php echo e($task->type_task == 'app' ? 'selected' : ''); ?>>Приложение</option>
                                        </select>
                                        <?php $__errorArgs = ['type_task'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="type_position">Позиция:</label>
                                        <select class="form-control <?php $__errorArgs = ['type_position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="type_position" name="type_position">
                                            <option value="" selected>-- Выберите позицию в какой части сайта будет ваш контент</option>
                                            <option value="header"  <?php echo e(old('type_position') == 'header' ? 'selected' : ''); ?> <?php echo e($task->type_position == 'header' ? 'selected' : ''); ?>>В хедере</option>
                                            <option value="sidebar" <?php echo e(old('type_position') == 'sidebar' ? 'selected' : ''); ?> <?php echo e($task->type_position == 'sidebar' ? 'selected' : ''); ?>>В сайдбаре</option>
                                            <option value="content" <?php echo e(old('type_position') == 'content' ? 'selected' : ''); ?> <?php echo e($task->type_position == 'content' ? 'selected' : ''); ?>>В общем контенте</option>
                                            <option value="footer"  <?php echo e(old('type_position') == 'footer' ? 'selected' : ''); ?> <?php echo e($task->type_position == 'footer' ? 'selected' : ''); ?>>В футере</option>
                                        </select>
                                        <?php $__errorArgs = ['type_position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <?php echo $__env->make('__shared.component.categories' , ['categories' => $categories , 'current' => $task], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>


                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">Обновить</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>ClassicEditor
                .create( document.querySelector( '#editor' ), {
                    wordCount: {
                        onUpdate: stats => {
                            if (stats.characters > 100) {
                                $('textarea').attr('maxlength' , 100).attr('readOnly' , false)
                            }
                            $('#character-count').text(stats.characters);
                        }
                    },
                    toolbar: {
                        items: [
                            'heading',
                            '|',
                            'bold',
                            'italic',
                            'alignment',
                            'bulletedList',
                            'numberedList',
                            '|',
                            'indent',
                            'outdent',
                            'removeFormat',
                            'underline',
                            '|',
                            'horizontalLine',
                            'blockQuote',
                            'undo',
                            'redo'
                        ]
                    },
                    language: 'ru',
                    licenseKey: '',
                } )
                .then( editor => {
                    window.editor = editor
                });
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cabinet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/cabinets/customer/task/edit.blade.php ENDPATH**/ ?>
@extends('layouts.admin')

@section('title' , 'Панель управления')

@section('content')
    <div class="page-inner">
        <div class="card">
            <div class="card-body">
                //
            </div>
        </div>
    </div>
@endsection

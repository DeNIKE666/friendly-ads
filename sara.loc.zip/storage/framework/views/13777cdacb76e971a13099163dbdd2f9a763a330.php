

<?php $__env->startSection('title' , 'Личный кабинет пользователя'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-inner">
        //
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            /*$.notify({
                icon: 'flaticon-alarm-1',
                title: 'Ошибка',
                message: 'Произошла ошибка, при выполнении действия.',
            },{
                type: 'danger',
                placement: {
                    from: "top",
                    align: "center"
                },
                time: 1000,
            });*/
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cabinet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/cabinets/index.blade.php ENDPATH**/ ?>
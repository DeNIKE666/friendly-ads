

<?php $__env->startSection('title' , 'Управление пользователями'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold">Сайты</h2>
                    <h5 class="text-white op-7 mb-2">Все сайты пользователя</h5>
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        <div class="card">
            <div class="card-header">
                Список сайтов
            </div>
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <blockquote class="blockquote mb-0">
                        <p><?php echo e($site->short); ?></p>
                        <p>Название: <?php echo e($site->title); ?></p>
                        <p>Категория: <?php echo e($site->category->name); ?></p>
                        <p>Ссылка: <a href="<?php echo e($site->url); ?>">перейти</a></p>
                    </blockquote>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-center">НЕТ САЙТОВ</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/admin/users/sites.blade.php ENDPATH**/ ?>
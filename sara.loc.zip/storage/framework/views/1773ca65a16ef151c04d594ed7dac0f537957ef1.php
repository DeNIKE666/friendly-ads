

<?php $__env->startSection('title' , 'Профиль пользователя ' . $user->username); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold"><?php echo e($user->username); ?></h2>
                    <h5 class="text-white op-7 mb-2">Профиль пользователя</h5>
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        <div class="d-flex justify-content-center">
            <div class="col-md-8">
                <div class="card card-profile">
                    <div class="card-header">
                        <div class="profile-picture">
                            <div class="avatar avatar-xl">
                                <img src="<?php echo e(asset('images/noavatar.png')); ?>" alt="..." class="avatar-img rounded-circle">
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="user-profile text-center">
                            <div class="name"><?php echo e($user->username); ?></div>
                            <div class="job">
                                <?php if($user->type_account == 1): ?>
                                    Администратор
                                <?php elseif($user->type_account == 2): ?>
                                    Пользователь
                                <?php elseif($user->type_account == 3): ?>
                                    Исполнитель
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="row user-stats text-center">
                            <div class="col">
                                <div class="number"><?php echo e($user->sites->count()); ?></div>
                                <div class="title">Сайтов</div>
                            </div>
                            <div class="col">
                                <div class="number"><?php echo e($user->sites->sum('rating')); ?></div>
                                <div class="title">Рейтинг</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cabinet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/cabinets/account/profile.blade.php ENDPATH**/ ?>
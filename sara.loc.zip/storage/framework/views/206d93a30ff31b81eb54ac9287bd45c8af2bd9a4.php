

<?php $__env->startSection('title' , 'Предложения заказчиков'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold">Предложения <?php echo e($offers->count()); ?></h2>
                    <h5 class="text-white op-7 mb-2">Все предложения заказчиков на продвижение контента</h5>
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        <div class="row">
            <?php if($offers->isEmpty()): ?>
                <div class="col-md-12">
                    <div class="alert alert-danger mb-0" role="alert">
                        На данный момент нет новых предложений, ожидайте когда кто-то разместит задание.
                    </div>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="subscribe-task" data-id="<?php echo e($offer->id); ?>" class="col-md-3">
                        <div class="card card-post card-round">
                            <div class="card-body">
                                <div class="d-flex">
                                    <div class="avatar">
                                        <img src="<?php echo e(asset('images/noavatar.png')); ?>" alt="..." class="avatar-img rounded-circle">
                                    </div>
                                    <div class="info-post ml-2">
                                        <p class="username"><?php echo e($offer->user->username); ?></p>
                                        <div style="width: 285px" id="projectTitleTask">
                                            <?php echo e($offer->title); ?>

                                        </div>
                                    </div>
                                </div>
                                <div class="separator-solid"></div>
                                <p class="card-text text-black-50"><?php echo e($offer->limitDescription()); ?></p>
                                <p class="card-text m-0">Бюджет: <b><?php echo e($offer->amount); ?></b> руб. </p>
                                <p class="card-text m-0">Категория: <b><?php echo e($offer->category->name); ?></b></p>
                                <p class="card-text m-0">Бюджет на сайт: <b>550</b> руб. </p>
                                <p class="card-text m-0">Срок: <b><?php echo e($offer->period); ?></b> дней. </p>

                                <p class="card-text m-0">
                                    Тип контента:
                                    <b><?php echo e(config('ads_friendly.type_task.' . $offer->type_task )); ?> </b>
                                </p>

                                <p class="card-text">
                                    Позиция размещения:
                                    <b><?php echo e(config('ads_friendly.type_position.' . $offer->type_position )); ?> </b>
                                </p>


                                <?php if($offer->IsResponses()): ?>
                                    <p class="card-text text-success fw-bold">
                                        Максимальный набор: <i class="fal fa-box-check"></i>
                                    </p>
                                <?php else: ?>
                                    <p class="card-text">
                                        Требуется сайтов:
                                        <b><?php echo e($offer->site_count); ?> / <?php echo e($offer->subscribe->count()); ?>  </b>
                                    </p>
                                <?php endif; ?>


                                <div class="d-flex justify-content-between">

                                    <a href="<?php echo e(route('executor.show.task', $offer)); ?>" class="btn btn-primary btn-rounded"><i class="fal fa-eye"></i> Просмотр</a >

                                    <?php if($offer->yourSubscribe): ?>
                                        <button data-id="<?php echo e($offer->yourSubscribe->id); ?>" class="btn btn-danger btn-rounded unsubscribe"> Отозвать отклик</button>
                                    <?php else: ?>
                                        <button data-id="<?php echo e($offer->id); ?>" class="btn btn-success btn-rounded task">Откликнутся</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <?php echo e($offers->links()); ?>

    </div>

    <!-- Modal -->
    <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Подписка на задачу</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <?php if(! auth()->user()->sites()->IsActive()->count()): ?>
                        <div class="alert alert-danger" role="alert">
                            Извините, у вас нет активированных сайтов, вам необходимо <a href="<?php echo e(route('executor.sites.create')); ?>"><b>добавить</b></a> сайт в систему и дождаться активации.
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info" role="alert">
                            Отлично, вас заинтересовал проект.
                            Укажите пожалуйста из вашего списка сайты на которых вы готовы разместить рекламу данного заказчика.
                        </div>
                    <?php endif; ?>
                        <div class="select2-input select2-warning">
                            <select id="multiple" name="sites[]" class="form-control is-invalid" multiple="multiple">
                                <?php $__currentLoopData = auth()->user()->sites()->isActive()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($site->url); ?>"><?php echo e($site->url); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                    <div id="errors"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary subscribe">Добавить</button>
                    <button type="button" class="btn btn-secondary close-modal" data-dismiss="modal">Закрыть</button>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            $('#multiple').select2({
                width: '100%',
                placeholder: "Выберите сайт",
                allowClear: true,
                theme: "bootstrap"
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cabinet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/cabinets/executor/offers/index.blade.php ENDPATH**/ ?>
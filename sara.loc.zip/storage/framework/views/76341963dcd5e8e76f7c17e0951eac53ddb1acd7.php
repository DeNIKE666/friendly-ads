<?php $__env->startSection('title', __('Ведутся технические работы')); ?>
<?php $__env->startSection('code', '503'); ?>
<?php $__env->startSection('message', __('Ведутся технические работы')); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/errors/503.blade.php ENDPATH**/ ?>
<div class="user">
    <div class="info">
        <a>
			<span>
			  <?php echo e(auth()->user()->username); ?>

			  <span class="user-level">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer')): ?>
                      Заказчик
                  <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('executor')): ?>
                      Исполнитель
                  <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                      Администратор
                  <?php endif; ?>
              </span>
			</span>
        </a>
        <div class="dropdown-divider"></div>
        <div class="d-flex justify-content-between">
            <button data-account="3" class="btn btn-outline-secondary btn-xs change <?php echo e(auth()->user()->type_account == 3 ? 'type_account_active' : ''); ?>">Я ИСПОЛНИТЕЛЬ</button>
            <button data-account="2" class="btn btn-outline-secondary btn-xs change <?php echo e(auth()->user()->type_account == 2 ? 'type_account_active' : ''); ?>">Я ЗАКАЗЧИК</button>
        </div>

        <hr>

        <span class="text-center text-black-50">Баланс аккаунта: <b><?php echo e(auth()->user()->balance); ?></b> руб. </span>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer')): ?>
            <a href="<?php echo e(route('balance')); ?>">пополнить</a>
        <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('executor')): ?>
            <a href="">вывести</a>
        <?php endif; ?>

        <div class="clearfix"></div>

    </div>
</div><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/__shared/cabinets/user.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title' , 'Мои задания'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold">Задачи</h2>
                    <h5 class="text-white op-7 mb-2">Список всех ваших заданий</h5>
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
            <?php if($tasks->isEmpty()): ?>
            <div class="card">
                <div class="alert alert-danger mb-0" role="alert">
                    У вас еще нет задач, но вы можете добавить их в систему <a href="<?php echo e(route('customer.tasks.create')); ?>"><b>добавить</b></a>
                </div>
            </div>
            <?php else: ?>
            <table>
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Выделенный бюджет</th>
                    <th scope="col">Требуется сайтов</th>
                    <th scope="col">Категория</th>
                    <th scope="col">Период</th>
                    <th scope="col">Просмотров</th>
                    <th scope="col">Откликов</th>
                    <th scope="col"></th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td data-label="#"><a href="<?php echo e(route('frontend.task.detail', $task)); ?>"><?php echo e($task->id); ?></a></td>
                        <td data-label="Выделенный бюджет"><?php echo e($task->amount); ?> руб. </td>
                        <td data-label="Требуется сайтов"><?php echo e($task->site_count); ?></td>
                        <td data-label="Категория"><?php echo e($task->category->name); ?></td>
                        <td data-label="Период"><?php echo e($task->period); ?> дней. </td>
                        <td data-label="Просмотров"><?php echo e($task->views); ?></td>
                        <td data-label="Откликов"><?php echo e($task->subscribe->count()); ?></td>
                        <td data-label="">
                            <div class="d-flex justify-content-end">
                                <a href="<?php echo e(route('customer.tasks.show', $task)); ?>" class="btn btn-primary btn-sm w-100  mr-1"><i class="fal fa-eye"></i></a>
                                <a href="<?php echo e(route('customer.tasks.edit', $task)); ?>" class="btn btn-primary btn-sm w-100  mr-1"><i class="fal fa-edit"></i></a>
                                <form action="<?php echo e(route('customer.tasks.destroy', $task)); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"  class="btn btn-danger btn-sm w-100  mr-1"><i class="fal fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>

        <div class="d-flex justify-content-center">
            <?php echo e($tasks->links()); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cabinet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/cabinets/customer/task/index.blade.php ENDPATH**/ ?>
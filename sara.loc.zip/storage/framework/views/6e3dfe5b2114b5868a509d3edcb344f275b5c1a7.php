<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <link rel="stylesheet" href="<?php echo e(mix('/assets/cabinet/css/atlantis.css')); ?>">
</head>

<body class="login bg-default">

<div class="wrapper wrapper-login">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<script src="<?php echo e(mix('/assets/cabinet/js/vendor_atlantis.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/cabinet/js/atlantis2.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/layouts/account.blade.php ENDPATH**/ ?>
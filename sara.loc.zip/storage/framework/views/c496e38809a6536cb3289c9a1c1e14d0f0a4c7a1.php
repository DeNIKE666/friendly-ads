<div class="form-group">
    <label for="user_id" class="col-form-label">Выбрать пользователя:</label>
    <select id="user_id" class="form-control<?php echo e($errors->has('user_id') ? ' is-invalid' : ''); ?>" name="user_id">
        <option value="">-- Выберите пользователя</option>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>"
                    <?php if(isset($current)): ?>
                        <?php echo e($user->id == $current ? 'selected' : ''); ?>

                    <?php endif; ?>
                    <?php echo e($user->id == old('user_id') ? ' selected' : ''); ?>>
                <?php echo e($user->username); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
    </select>
    <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback">
            <strong>
                <?php echo e($message); ?>

            </strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/__shared/component/users.blade.php ENDPATH**/ ?>
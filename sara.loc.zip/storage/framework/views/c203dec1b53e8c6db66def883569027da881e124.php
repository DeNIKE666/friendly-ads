<div class="form-group">
    <label for="parent_id" class="col-form-label">Выбрать родительскую категорию:</label>
    <select id="parent_id" class="form-control<?php echo e($errors->has('parent_id') ? ' is-invalid' : ''); ?>" name="parent_id">
        <option value="">-- Выберите категорию</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($parent->id); ?>"<?php echo e($parent->id == old('parent_id') ? ' selected' : ''); ?>>
                <?php for($i = 0; $i < $parent->depth; $i++): ?> &mdash; <?php endfor; ?>
                <?php echo e($parent->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
    </select>
    <?php $__errorArgs = ['parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback">
            <strong>
                <?php echo e($message); ?>

            </strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/__shared/component/admin/categories.blade.php ENDPATH**/ ?>
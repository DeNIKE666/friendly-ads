

<?php $__env->startSection('title' , 'Редактировать задание'); ?>

<?php $__env->startSection('content'); ?>
    <update-task :current="<?php echo e($task); ?>" :categories="<?php echo e($categories); ?>"></update-task>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cabinet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/cabinets/customer/task/edit.blade.php ENDPATH**/ ?>
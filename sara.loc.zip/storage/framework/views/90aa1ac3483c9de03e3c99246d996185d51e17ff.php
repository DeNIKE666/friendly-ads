

<?php $__env->startSection('title' , 'Панель управления'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="card">
            <div class="card-body">
                //
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/admin/index.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title' , 'Редактирование категории'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('categories.update', $category)); ?>" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Имя категории:</label>
                        <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', $category->name)); ?>">
                    </div>

                    <div class="form-group">
                        <label for="parent_id" class="col-form-label">Родительская категория:</label>
                        <select id="parent_id" class="form-control<?php echo e($errors->has('parent_id') ? ' is-invalid' : ''); ?>" name="parent_id">
                            <option value=""></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($parent->id); ?>"<?php echo e($parent->id == old('parent_id', $category->parent_id) ? ' selected' : ''); ?>>
                                    <?php for($i = 0; $i < $parent->depth; $i++): ?> &mdash; <?php endfor; ?>
                                    <?php echo e($parent->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
                        </select>
                        <?php if($errors->has('parent_id')): ?>
                            <span class="invalid-feedback"><strong><?php echo e($errors->first('parent_id')); ?></strong></span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">ОБНОВИТЬ</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>
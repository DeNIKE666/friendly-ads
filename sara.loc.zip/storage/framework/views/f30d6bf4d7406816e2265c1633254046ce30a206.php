<?php echo e($slot); ?>

<?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>
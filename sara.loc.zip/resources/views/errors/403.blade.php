@extends('errors::minimal')

@section('title', 'Нет доступа к данной странице')
@section('code', '403')
@section('message', 'Нет доступа к данному разделу')

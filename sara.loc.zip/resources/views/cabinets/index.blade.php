@extends('layouts.cabinet')

@section('title' , 'Личный кабинет пользователя')

@section('content')

    <div class="page-inner">
        //
    </div>

    @push('scripts')
        <script>
            /*$.notify({
                icon: 'flaticon-alarm-1',
                title: 'Ошибка',
                message: 'Произошла ошибка, при выполнении действия.',
            },{
                type: 'danger',
                placement: {
                    from: "top",
                    align: "center"
                },
                time: 1000,
            });*/
        </script>
    @endpush
@endsection
Теперь вы стали пользователем нашего проекта, спасибо. <br><br>
<p><b>Данные для входа:</b></p>
<p>E-mail: <?php echo e($email); ?></p>
<p>Пароль: <?php echo e($password); ?></p>
<hr>
<br>
Благодарим за интерес к нашему сервису.<?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/email/admin/userCreateNotify.blade.php ENDPATH**/ ?>
<!-- Sidebar -->
<div class="sidebar sidebar-style-2">
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">

            <?php echo $__env->make('__shared.cabinets.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <ul class="nav nav-primary">

                <li class="nav-section">
                    <h4 class="text-section">Сайты</h4>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('executor.sites.index')); ?>">
                        <i class="fal fa-sitemap"></i>
                        <p>Все сайты</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('executor.sites.create')); ?>">
                        <i class="fal fa-layer-plus"></i>
                        <p>Добавить сайт</p>
                    </a>
                </li>

                <li class="nav-section">
                    <h4 class="text-section">Работа</h4>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('executor.offers')); ?>">
                        <i class="fal fa-briefcase"></i>
                        <p>Все предложения</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('executor.subs.task')); ?>">
                        <i class="fal fa-paper-plane"></i>
                        <p>Мои отклики</p>
                    </a>
                </li>

            </ul>
        </div>
    </div>
</div>
<!-- End Sidebar -->
<?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/__shared/cabinets/menu_executor_sidebar.blade.php ENDPATH**/ ?>
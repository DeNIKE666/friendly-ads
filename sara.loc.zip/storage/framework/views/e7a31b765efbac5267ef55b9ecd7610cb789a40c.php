

<?php $__env->startSection('title' , 'Все сайты'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold">Все сайты</h2>
                    <h5 class="text-white op-7 mb-2">Список всеъ сайтов добавленых в проект</h5>
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        <div class="card">
            <?php if($sites->isEmpty()): ?>
                <div class="alert alert-danger mb-0" role="alert">
                    В системе пока нет сайтов пользователей
                </div>
            <?php else: ?>
            <table>
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Ссылка</th>
                    <th scope="col">Рейтинг</th>
                    <th scope="col">Категория</th>
                    <th scope="col">Пользователь</th>
                    <th scope="col">Статус</th>
                    <th scope="col"></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td data-label="#"><?php echo e($site->id); ?></td>
                        <td data-label="Ссылка"><?php echo e($site->url); ?></td>
                        <td data-label="Рейтинг"><?php echo e($site->rating); ?></td>
                        <td data-label="Категория"><?php echo e($site->category->name); ?></td>
                        <td data-label="Пользователь"><?php echo e($site->user->username); ?></td>
                        <td data-label="Статус"><?php echo e($site->activated  ? 'активирован' : 'не активирован'); ?></td>
                        <td data-label="">
                            <div class="d-flex justify-content-end">
                                <a href="<?php echo e(route('admin.sites.edit', $site)); ?>" class="btn btn-warning btn-sm w-100  mr-1"><i class="fal fa-edit"></i></a>
                                <form action="<?php echo e(route('admin.sites.destroy', $site)); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger btn-sm w-100  mr-1"><i class="fal fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
           <?php endif; ?>
        </div>

        <div class="d-flex justify-content-center">
            <?php echo e($sites->links()); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/admin/sites/index.blade.php ENDPATH**/ ?>
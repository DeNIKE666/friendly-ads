<div class="user">
    <div class="info">
        <a>
			<span>
			  <?php echo e(auth()->user()->username); ?>

			  <span class="user-level">
                  <?php if(auth()->user()->type_account == 1): ?>
                      Администратор
                  <?php elseif(auth()->user()->type_account == 2): ?>
                      Заказчик
                  <?php elseif(auth()->user()->type_account == 3): ?>
                      Исполнитель
                  <?php endif; ?>
              </span>
			</span>
        </a>
        <div class="dropdown-divider"></div>
        <div class="d-flex justify-content-between">
            <button data-account="3" class="btn btn-outline-secondary btn-xs change">Я ИСПОЛНИТЕЛЬ</button>
            <button data-account="2" class="btn btn-outline-info btn-xs change">Я ЗАКАЗЧИК</button>
        </div>
        <div class="clearfix"></div>
    </div>
</div><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/__shared/cabinets/user.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Все активные проекты пользователей'); ?>

<?php $__env->startSection('description' , config('ads_friendly.seo_pages.projects.description') ); ?>

<?php $__env->startSection('content'); ?>
    <section class="section-white box-shadow">
        <div class="container">
            <div class="row">
                <div class="tr-list-center">
                    <h2>Проекты пользователей</h2>
                    <p>все активные задания пользователей на площадке, вы можете с лёгкостью отфильровать нужные категории, и приступить к заказу в
                        <b><a href="<?php echo e(route('executor.offers')); ?>">личном кабинете</a></b></p>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-4">
                    <div class="d-block d-none d-sm-block d-md-none mb-3">
                        <a href="javascript:void(0)" id="showFilters" class="btn btn-info full-width btn-md"><i class="ti-filter mrg-r-5"></i>Фильтры</a>
                    </div>
                    <div id="filters" class="sidebar-container d-sm-none d-md-block d-none">

                        <div class="sidebar-widget">
                            <div class="form-group">
                                <h5 class="mb-2">Категории:</h5>
                                <div class="side-imbo">
                                    <ul class="no-ul-list">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <input id="category_id-<?php echo e($category->id); ?>" data-id="<?php echo e($category->id); ?>" class="radio-custom" name="category" type="radio">
                                                <label for="category_id-<?php echo e($category->id); ?>" class="radio-custom-label"><?php echo e($category->name); ?></label>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="sidebar-widget">
                            <div class="form-group">
                                <h5 class="mb-2">Тип задания:</h5>
                                <div class="side-imbo">
                                    <ul class="no-ul-list">
                                        <li>
                                            <input id="type_task_link_product" data-id="link_product" class="radio-custom type_task" name="type_task" type="radio" value="link_product">
                                            <label for="type_task_link_product" class="radio-custom-label">Cсылка на продукт</label>
                                        </li>
                                        <li>
                                            <input id="type_task_link_video" data-id="link_video" class="radio-custom type_task" name="type_task" type="radio" value="link_video">
                                            <label for="type_task_link_video" class="radio-custom-label">Cсылка на видео</label>
                                        </li>
                                        <li>
                                            <input id="type_task_page" data-id="page" class="radio-custom type_task" name="type_task" type="radio" value="page">
                                            <label for="type_task_page" class="radio-custom-label">Cтраница сайта</label>
                                        </li>
                                        <li>
                                            <input id="type_task_app" data-id="app" class="radio-custom type_task" name="type_task" type="radio" value="app">
                                            <label for="type_task_app" class="radio-custom-label">Приложение</label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>


                        <div class="sidebar-widget">
                            <div class="form-group">
                                <h5 class="mb-2">Цены:</h5>
                                <div class="side-imbo">
                                    <ul class="no-ul-list">
                                        <li>
                                            <input id="prices-filters-1" data-id="1" class="radio-custom" name="amount" type="radio" value="1">
                                            <label for="prices-filters-1" class="radio-custom-label">Больше</label>
                                        </li>
                                        <li>
                                            <input id="prices-filters-2" data-id="2" class="radio-custom" name="amount" type="radio" value="2">
                                            <label for="prices-filters-2" class="radio-custom-label">Меньше</label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>


                        <!-- apply -->

                        <div class="sidebar-widget">
                            <div class="form-group">
                                <a href="#" id="apply-filter" class="btn btn-info full-width btn-md"><i class="ti-filter mrg-r-5"></i>Применить</a>
                                <a href="#" id="reset-filter" class="btn btn-secondary full-width btn-md mt-2"><i class="ti-filter mrg-r-5"></i>Сбросить</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-9 col-lg-8">
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="wrf-joblist">
                                    <div class="wrf-job-title-wrap">
                                        <h4 class="wrf-job-title verified-job">
                                            <a href="job-detail.html">
                                                <?php echo e($task->title); ?>

                                            </a>
                                        </h4>

                                        <hr>

                                        <ul class="p-0">
                                            <li class="pb-3">Заказчик: <?php echo e($task->user->username); ?></li>
                                            <li class="pb-2">Тип задания: <span class="highlight"><?php echo e(config('ads_friendly.type_task.' . $task->type_task)); ?></span></li>
                                            <li class="pb-2">Позиция размещения: <span class="highlight"><?php echo e(config('ads_friendly.type_position.' . $task->type_position)); ?></span></li>
                                            <li class="pb-2">Срок размещения: <span class="highlight"><?php echo e($task->period); ?> дней.</span></li>
                                            <li class="pb-2">Откликнулись: <span class="highlight"><?php echo e($task->subscribe->count()); ?> исполнителей</span></li>
                                            <li class="pb-2">Категория: <span class="highlight"><?php echo e($task->category->name); ?></span></li>

                                        </ul>

                                    </div>
                                    <div class="wrf-job-caption">
                                        <p class="content-text truncateMe"><?php echo e($task->description); ?></p>
                                        <a href="<?php echo e(route('frontend.task.detail', $task)); ?>">Перейти к заданию</a>

                                        <div class="d-flex justify-content-between mt-4">
                                            <span><i class="fal fa-eye"></i> <?php echo e($task->views); ?></span>
                                            <span><i class="fal fa-ruble-sign"></i> <?php echo e($task->amount()); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-lg-12 col-md-12 col-sm-6">
                                <div class="alert alert-light text-center" role="alert">
                                    НА ДАННЫЙ МОМЕНТ ОТСУТСТВУЮТ ПРОЕКТЫ
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>

                    <!-- Pagination -->
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <?php echo e($tasks->withQueryString()->links()); ?>

                        </div>
                    </div>
                    <!-- Pagination -->

                </div>

            </div>

        </div>
    </section>

    <?php $__env->startPush('scripts'); ?>
        <?php echo $__env->make('__shared.frontend.filters.projects_filters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/frontend/projects/index.blade.php ENDPATH**/ ?>
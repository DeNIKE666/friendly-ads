

<?php $__env->startSection('title', 'Просмотр задания - ' . $task->title); ?>

<?php $__env->startSection('description', 'Подробное описание задания'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section-white box-shadow">
        <div class="container">
            <div class="row">
                <div class="tr-list-center">
                    <h2><?php echo e($task->title); ?></h2>
                    <p>размещённый проект на площадке от пользователя <span class="badge badge-secondary"><?php echo e($task->user->username); ?></span> , старайтесь как можно быстрее оставить свой отклик. </p>
                </div>
            </div>
        </div>
    </section>
    <section class="tr-single-detail gray-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-12 col-sm-12">
                    <div class="tr-single-box">
                        <div class="tr-single-header">
                            <h4><i class="ti-info"></i>Описание</h4>
                        </div>
                        <div class="tr-single-body">
                           <?php echo $task->description; ?>

                        </div>
                    </div>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer')): ?>
                        <a href="<?php echo e(route('executor.show.task', $task)); ?>" class="btn btn-outline-info full-width mb-2"> ПЕРЕЙТИ К СВОЕМУ ЗАДАНИЮ</a>
                    <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('executor')): ?>
                        <a href="<?php echo e(route('executor.show.task', $task)); ?>" class="btn btn-outline-info full-width mb-2"> ОСТАВИТЬ ОТКЛИК</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('executor.show.task', $task)); ?>" class="btn btn-outline-info full-width mb-2"> ПЕРЕЙТИ К ЗАДАНИЮ</a>
                    <?php endif; ?>
                </div>

                <div class="col-lg-4 col-md-12 col-sm-12">
                    <div class="tr-single-box">
                        <div class="tr-single-header">
                            <h4><i class="ti-book"></i> Требования к исполнителю</h4>
                        </div>
                        <div class="tr-single-body">
                            <ul class="jb-detail-list">
                                <li>Тип задания: <b><?php echo e(config('ads_friendly.type_task.' . $task->type_task)); ?></b></li>
                                <li>Позиция размещения: <b><?php echo e(config('ads_friendly.type_position.' . $task->type_position)); ?></b></li>
                            </ul>
                        </div>
                    </div>
                    <div class="tr-single-box">
                        <div class="tr-single-header">
                            <h4><i class="ti-direction"></i> Информация</h4>
                        </div>
                        <div class="tr-single-body">
                            <ul class="extra-service">
                                <li>
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fal fa-ruble-sign"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Цена</strong>
                                            <?php echo e($task->amount()); ?>

                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fal fa-box-check"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Откликов</strong>
                                            <?php echo e($task->subscribe->count()); ?>

                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon-box-icon-block">
                                        <div class="icon-box-round">
                                            <i class="fal fa-clock"></i>
                                        </div>
                                        <div class="icon-box-text">
                                            <strong class="d-block">Период</strong>
                                            <?php echo e($task->period); ?> дней
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /col-md-4 -->
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/frontend/tasks/show.blade.php ENDPATH**/ ?>
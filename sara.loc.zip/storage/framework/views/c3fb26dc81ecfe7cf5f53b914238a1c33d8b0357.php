

<?php $__env->startSection('title' , 'Добавить новую задачу'); ?>

<?php $__env->startSection('content'); ?>
    <create-task :categories="<?php echo e($categories); ?>"></create-task>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cabinet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/cabinets/customer/task/create.blade.php ENDPATH**/ ?>
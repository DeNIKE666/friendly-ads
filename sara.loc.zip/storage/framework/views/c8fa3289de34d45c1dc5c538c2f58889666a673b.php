

<?php $__env->startSection('title' , 'Отклики на задание - #' . $task->id); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold">Задание - #<?php echo e($task->id); ?></h2>
                    <h5 class="text-white op-7 mb-2">Моё опубликованное задание на проекте</h5>
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        <div class="d-flex justify-content-center">
            <div id="subscribe-task" data-id="<?php echo e($task->id); ?>" class="col-md-6">
                <div class="card card-post card-round">
                    <div class="card-body">
                        <div class="d-flex">
                            <div class="avatar">
                                <img src="<?php echo e(asset('images/noavatar.png')); ?>" alt="..." class="avatar-img rounded-circle">
                            </div>
                            <div class="info-post ml-2">
                                <p class="username"><?php echo e($task->user->username); ?></p>
                                <div id="task-title" style="width: 285px">
                                    <?php echo e($task->title); ?>

                                </div>
                            </div>
                        </div>
                        <div class="separator-solid"></div>
                        <p class="card-text text-black-50"><?php echo e($task->description); ?></p>
                        <p class="card-text">Бюджет: <b><?php echo e(number_format($task->amount , 0 , ', ' , ' ')); ?></b> руб. </p>
                        <p class="card-text">Срок: <b><?php echo e($task->period); ?></b> дней. </p>
                        <p class="card-text">Категория: <b><?php echo e($task->category->name); ?></b></p>
                        <p class="card-text">Требуется сайтов: <b><?php echo e($task->site_count); ?> / <?php echo e($task->subscribeAccepted()->count()); ?> </b></p>
                        <p class="card-text">Тип контента:<b><?php echo e(config('ads_friendly.type_task.' . $task->type_task )); ?> </b></p>
                        <p class="card-text">Позиция размещения:<b><?php echo e(config('ads_friendly.type_position.' . $task->type_position )); ?> </b></p>
                        <table>
                            <thead>
                            <tr>
                                <th scope="col">Пользователь</th>
                                <th scope="col">Рейтинг</th>
                                <th scope="col">Сайт</th>
                                <th scope="col">Статус</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $task->subscribe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $executor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td data-label="Пользователь">
                                        <a href="<?php echo e(route('cabinet.show.profile', $executor->user)); ?>">
                                            <?php echo e($executor->user->username); ?>

                                        </a>
                                    </td>
                                    <td data-label="Рейтинг"><?php echo e($executor->user->sites->sum('rating')); ?></td>
                                    <td data-label="Сайт">
                                        <a href="<?php echo e($executor->sites); ?>">перейти</a>
                                    </td>
                                    <td data-label="Статус">
                                        <?php switch($executor->status):
                                            case (1): ?>
                                            <i class="text-success fal fa-check" data-toggle="tooltip" data-placement="top" title="Принят в проект"></i>
                                            <?php break; ?>
                                            <?php case (2): ?>
                                            <i class="text-danger fal fa-times" data-toggle="tooltip" data-placement="top" title="Отклонён"></i>
                                            <?php break; ?>
                                            <?php case (0): ?>
                                                <?php if(! $executor->task->isFull()): ?>
                                                   <button data-id="<?php echo e($executor->id); ?>" class="btn btn-primary accept-task btn-sm"><i class="fal fa-check"></i></button>
                                                <?php endif; ?>
                                                <?php if($executor->status == 0): ?>
                                                    <button data-id="<?php echo e($executor->id); ?>" class="btn btn-danger reject-task btn-sm"><i class="fal fa-times"></i></button>
                                                <?php endif; ?>
                                            <?php break; ?>
                                        <?php endswitch; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php if($task->subscribeAccepted()->count() >= $task->site_count): ?>
                            <div class="alert alert-info mb-3 mt-3" role="alert">
                                Ваш заказ набрал максимальное число откликов, теперь вы можете <b>зарезервировать средства в системе</b>, и создать персональный код размешения на сайтах, для каждого исполнителя.
                            </div>
                           <div id="work">
                               <?php switch($task->isPay):
                                   case (0): ?>
                                   <form action="<?php echo e(route('order.pay.task', $task)); ?>" method="POST">
                                       <?php echo csrf_field(); ?>
                                       <button class="btn btn-info-gradiant create-order-pay"><i class="fal fa-user-check"></i> <span id="text-pay-btn">Создать и оплатить заказ </span></button>
                                   </form>
                                   <?php break; ?>
                                   <?php case (1): ?>
                                      Заказ создан но не оплачен
                                   <?php break; ?>
                                   <?php case (2): ?>
                                      Заказ оплачен
                                   <?php break; ?>
                               <?php endswitch; ?>
                           </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            let taskId = $('#subscribe-task').data('id');

            let reject = $('.reject-task');
            let accept = $('.accept-task');

            reject.click(function () {
                let id = $(this).data('id');
                $.ajax({
                    type: "POST",
                    url: "/cabinet/manage-task/reject/" + id,
                    success: function (resp) {
                        $('#executor-' + id).fadeOut('slow');
                    }
                })
            })

            accept.click(function () {
                let id = $(this).data('id');
                $.ajax({
                    type: "POST",
                    url: "/cabinet/manage-task/accept/" + id,
                    success: function (resp) {
                        window.location.href = '/cabinet/tasks/' + taskId
                    }
                })
            })
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cabinet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/cabinets/customer/task/show.blade.php ENDPATH**/ ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(mix('/assets/cabinet/css/atlantis.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
<div class="wrapper" id="app">

    <?php echo $__env->make('__shared.cabinets.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer')): ?>
        <?php echo $__env->make('__shared.cabinets.menu_customer_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('executor')): ?>
        <?php echo $__env->make('__shared.cabinets.menu_executor_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <div class="main-panel">
        <div class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <footer class="footer">
            <div class="container-fluid">
                <div class="copyright">
                    developed <i class="fa fa-heart heart text-danger"></i> by <a href="https://t.me/AppEXEdev">DevPlus</a>
                </div>
            </div>
        </footer>
    </div>
</div>
<script src="<?php echo e(mix('/assets/cabinet/js/app.js')); ?>"></script>
<script src="<?php echo e(mix('/assets/cabinet/js/vendor_atlantis.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/cabinet/js/atlantis2.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/ckeditor/build/ckeditor.js')); ?>"></script>
<script src="https://ckeditor.com/apps/ckfinder/3.5.0/ckfinder.js"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>

<script>
    <?php if(session()->has('error')): ?>
        swal({
            icon: 'error',
            text: '<?php echo e(session()->get('error')); ?>'
        })
    <?php endif; ?>

</script>
</body>
</html>
<?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/layouts/cabinet.blade.php ENDPATH**/ ?>
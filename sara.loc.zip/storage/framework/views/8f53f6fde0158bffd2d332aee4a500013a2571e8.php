

<?php $__env->startSection('title' , 'Управление категориями'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold">Категории</h2>
                    <h5 class="text-white op-7 mb-2">Список всех категорий добавленых в проект</h5>
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        <div class="card">
            <?php if($categories->isEmpty()): ?>
                <div class="card">
                    <div class="alert alert-danger mb-0" role="alert">
                        В системе пока нет категорий
                    </div>
                </div>
            <?php else: ?>
                <table>
                    <thead>
                    <tr>
                        <th scope="col">Название</th>
                        <th scope="col">Путь</th>
                        <th scope="col"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="Название">
                                <?php for($i = 0; $i < $category->depth; $i++): ?> &mdash; <?php endfor; ?>
                                <a href=""><?php echo e($category->name); ?></a>
                            </td>
                            <td data-label="Путь"><?php echo e($category->getPath()); ?></td>
                            <td data-label="Действия">
                                <div class="d-flex justify-content-end">
                                    <form class="mr-1">
                                        <a href="<?php echo e(route('categories.edit', $category)); ?>"
                                           class="btn btn-sm btn-outline-primary"><span class="fad fa-edit"></span></a>
                                    </form>

                                    <form method="POST" action="<?php echo e(route('categories.first', $category)); ?>"
                                          class="mr-1">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-sm btn-outline-primary"><span
                                                    class="fa fa-angle-double-up"></span></button>
                                    </form>
                                    <form method="POST" action="<?php echo e(route('categories.up', $category)); ?>" class="mr-1">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-sm btn-outline-primary"><span
                                                    class="fa fa-angle-up"></span></button>
                                    </form>
                                    <form method="POST" action="<?php echo e(route('categories.down', $category)); ?>" class="mr-1">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-sm btn-outline-primary"><span
                                                    class="fa fa-angle-down"></span></button>
                                    </form>
                                    <form method="POST" action="<?php echo e(route('categories.last', $category)); ?>" class="mr-1">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-sm btn-outline-primary"><span
                                                    class="fa fa-angle-double-down"></span></button>
                                    </form>
                                    <form method="POST" action="<?php echo e(route('categories.destroy', $category)); ?>"
                                          class="mr-1">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-sm btn-outline-primary"><span
                                                    class="fas fa-trash-alt"></span></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" class="text-center">НЕТ КАТЕГОРИЙ</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title' , 'Мои отклики на предложения'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold">Отклики (<span id="subsCount"><?php echo e($offers->count()); ?></span>)</h2>
                    <h5 class="text-white op-7 mb-2">Мои отклики на предложение заказчиков</h5>
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        <div class="row">
            <?php if(! $offers->count()): ?>
                <div class="col-md-12">
                    <div class="card">
                        <div class="alert alert-danger mb-0" role="alert">
                            На данный момент нет откликов.
                        </div>
                    </div>
                </div>
            <?php else: ?>
            <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="subscribe-task-<?php echo e($offer->id); ?>" class="col-md-3">
                    <div class="card card-post card-round">
                        <div class="card-body">
                            <div class="d-flex">
                                <div class="avatar">
                                    <img src="<?php echo e(asset('images/noavatar.png')); ?>" alt="..." class="avatar-img rounded-circle">
                                </div>
                                <div class="info-post ml-2">
                                    <p class="username"><?php echo e($offer->title); ?></p>
                                    <div style="width: 285px">
                                        <?php echo e($offer->user->username); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="separator-solid"></div>
                            <p class="card-category text-info mb-1"><a href="#"><?php echo e($offer->category->name); ?></a>
                            </p>
                            <p class="card-text text-black-50"><?php echo e($offer->limitDescription()); ?></p>
                            <p class="card-text m-0">Бюджет: <b><?php echo e($offer->amount); ?></b> руб. </p>
                            <p class="card-text m-0">Бюджет на сайт: <b>550</b> руб. </p>
                            <p class="card-text m-0">Срок: <b><?php echo e($offer->period); ?></b> дней. </p>

                            <p class="card-text m-0">
                                Тип контента:
                                <b><?php echo e(config('ads_friendly.type_task.' . $offer->type_task )); ?> </b>
                            </p>

                            <p class="card-text">
                                Позиция размещения:
                                <b><?php echo e(config('ads_friendly.type_position.' . $offer->type_position )); ?> </b>
                            </p>

                            <p class="card-text text-secondary">
                                Требуется сайтов:
                                <b><?php echo e($offer->site_count); ?> / <?php echo e($offer->subscribe()->count()); ?>  </b>
                            </p>

                            <div class="d-flex justify-content-between">
                                <?php if($offer->yourSubscribe): ?>

                                    <a href="<?php echo e(route('executor.show.task', $offer)); ?>" class="btn btn-primary btn-rounded">
                                        <i class="fal fa-eye"></i> Просмотр
                                    </a>

                                    <button data-id="<?php echo e($offer->id); ?>" class="btn btn-danger btn-rounded unsubscribe">
                                        Отозвать отклик
                                    </button>
                                <?php else: ?>
                                    <button data-id="<?php echo e($offer->id); ?>" class="btn btn-success btn-rounded subscribe">
                                        Откликнутся
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cabinet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/cabinets/executor/offers/subs.blade.php ENDPATH**/ ?>
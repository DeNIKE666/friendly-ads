@extends('errors::minimal')

@section('title', __('Ведутся технические работы'))
@section('code', '503')
@section('message', __('Ведутся технические работы'))

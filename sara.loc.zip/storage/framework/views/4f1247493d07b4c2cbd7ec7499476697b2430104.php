

<!-- Sidebar -->
<div class="sidebar sidebar-style-2">
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">

            <?php echo $__env->make('__shared.cabinets.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <ul class="nav nav-primary">

                <li class="nav-section">
                    <h4 class="text-section">Продвижение</h4>
                </li>


                <li class="nav-item">
                    <a href="<?php echo e(route('customer.performers')); ?>">
                        <i class="fal fa-user-chart"></i>
                        <p>Исполнители</p>
                    </a>
                </li>

                <li class="nav-section">
                    <h4 class="text-section">Задачи</h4>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('customer.tasks.index')); ?>">
                        <i class="fal fa-tasks"></i>
                        <p>Мои задания</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('customer.tasks.create')); ?>">
                        <i class="fal fa-plus-circle"></i>
                        <p>Создать задание</p>
                    </a>
                </li>

                <li class="nav-section">
                    <h4 class="text-section">Финансы</h4>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('balance')); ?>">
                        <i class="fal fa-wallet"></i>
                        <p>Пополнить баланс</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('history')); ?>">
                        <i class="fal fa-history"></i>
                        <p>История пополнений</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="">
                        <i class="fal fa-repeat-alt"></i>
                        <p>Расходы</p>
                    </a>
                </li>

            </ul>
        </div>
    </div>
</div>
<!-- End Sidebar -->
<?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/__shared/cabinets/menu_customer_sidebar.blade.php ENDPATH**/ ?>
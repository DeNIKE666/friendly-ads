<?php echo e($slot); ?>

<?php /**PATH D:\OpenServer\domains\sara.loc\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>
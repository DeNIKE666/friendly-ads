<div class="form-group">
    <label for="category_id" class="col-form-label">Выбрать категорию:</label>
    <select id="category_id" class="form-control<?php echo e($errors->has('category_id') ? ' is-invalid' : ''); ?>" name="category_id">
        <option value="">-- Выберите категорию</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($parent->id); ?>"
                    <?php if(isset($current)): ?>
                     <?php echo e($parent->id == $current->category_id ? 'selected' : ''); ?>

                    <?php endif; ?>
                    <?php echo e($parent->id == old('category_id') ? ' selected' : ''); ?>>
                <?php for($i = 0; $i < $parent->depth; $i++): ?> &mdash; <?php endfor; ?>
                <?php echo e($parent->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
    </select>
    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback">
            <strong>
                <?php echo e($message); ?>

            </strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/__shared/component/categories.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title' , 'Мои отклики на предложения'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold">Отклики (<span id="subsCount"><?php echo e($offers->count()); ?></span>)
                    </h2>
                    <h5 class="text-white op-7 mb-2">Мои отклики на предложение заказчиков</h5>
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        <div class="row">
            <?php if(! $offers->count()): ?>
                <div class="col-md-12">
                    <div class="card">
                        <div class="alert alert-danger mb-0" role="alert">
                            На данный момент нет откликов.
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="subscribe-task-<?php echo e($offer->yourSubscribe->id); ?>" class="col-md-3">
                        <div class="card card-post card-round">
                            <div class="card-body">
                                <div class="d-flex">
                                    <div class="avatar">
                                        <img src="<?php echo e(asset('images/noavatar.png')); ?>" alt="..."
                                             class="avatar-img rounded-circle">
                                    </div>
                                    <div class="info-post ml-2">
                                        <p class="username"><?php echo e($offer->title); ?></p>
                                        <div style="width: 285px">
                                            <?php echo e($offer->user->username); ?>

                                        </div>
                                    </div>
                                </div>
                                <div class="separator-solid"></div>
                                <p class="card-text text-black-50"><?php echo e($offer->limitDescription()); ?></p>
                                <p class="card-text">Бюджет: <b><?php echo e($offer->amount); ?></b> руб. </p>
                                <p class="card-text">Срок: <b><?php echo e($offer->period); ?></b> дней. </p>
                                <p class="card-text">Категория: <b><?php echo e($offer->category->name); ?></b></p>
                                <p class="card-text">Требуется сайтов: <b><?php echo e($offer->site_count); ?>

                                        / <?php echo e($offer->subscribeAccepted()->count()); ?> </b></p>
                                <p class="card-text">Тип
                                    контента:<b><?php echo e(config('ads_friendly.type_task.' . $offer->type_task )); ?> </b></p>
                                <p class="card-text">Позиция
                                    размещения:<b><?php echo e(config('ads_friendly.type_position.' . $offer->type_position )); ?> </b>
                                </p>
                                <div>
                                    <span>Статус задания:</span>
                                    <span>
                                    <?php if($offer->isFull() ): ?>
                                            <i class="text-danger fw-bold fal fa-lock" data-toggle="tooltip"
                                               data-placement="top"
                                               title="Задание недоступно для откликов"></i>
                                        <?php else: ?>
                                            <i class="text-success fw-bold fal fa-lock-open" data-toggle="tooltip"
                                               data-placement="top"
                                               title="Задание доступно для откликов"></i>
                                        <?php endif; ?>
                                    </span>
                                </div>

                                <div>
                                    <hr>
                                    <?php if($offer->isFull()): ?>
                                        <p class="text-dark <?php echo e($offer->yourSubscribe->status ? 'text-success' : ''); ?>">
                                            <i class="fal fa-check"></i>
                                            <?php echo e($offer->yourSubscribe->status ? 'вас выбрали в данном заказе' : 'исполнитель найден'); ?>

                                        </p>
                                    <?php else: ?>
                                        <?php switch($offer->yourSubscribe->status):
                                            case (1): ?>
                                            <p class="text-dark text-success">
                                                <i class="fal fa-check"></i>
                                                ваш отклик был одобрен заказчиком
                                            </p>
                                            <?php break; ?>
                                            <?php case (2): ?>
                                            <p class="text-dark text-danger">
                                                <i class="fal fa-times"></i>
                                                ваш отклик был отклонён
                                            </p>
                                            <?php break; ?>
                                            <?php case (0): ?>
                                            <p class="text-dark text-warning">
                                                <i class="fal fa-clock"></i>
                                                На рассмотрении...
                                            </p>
                                            <?php break; ?>
                                        <?php endswitch; ?>
                                    <?php endif; ?>
                                    <hr>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <?php if($offer->isFull()): ?>
                                        <a href="<?php echo e(route('executor.show.task', $offer)); ?>"
                                           class="btn btn-primary btn-rounded w-100"><i class="fal fa-eye"></i> Просмотр</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('executor.show.task', $offer)); ?>"
                                           class="btn btn-primary btn-rounded"><i class="fal fa-eye"></i> Просмотр</a>
                                        <button data-id="<?php echo e($offer->yourSubscribe->id); ?>"
                                                class="btn btn-danger btn-rounded unsubscribe">Отозвать отклик
                                        </button>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            $('#hiddenInShow').on('click', function () {

                console.log(1)
            })
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cabinet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/cabinets/executor/offers/subs.blade.php ENDPATH**/ ?>
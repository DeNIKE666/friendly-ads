[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\OpenServer\domains\sara.loc\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>